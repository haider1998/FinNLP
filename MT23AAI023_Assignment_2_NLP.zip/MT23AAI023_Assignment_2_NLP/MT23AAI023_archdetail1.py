import numpy as np

def conv2d(input_feature_maps, kernels, stride=1, padding='same', activation='relu'):
    """
    Perform 2D convolution/cross-correlation operation on input feature maps with multiple kernels.
    
    Args:
        input_feature_maps: Input tensor of shape (height, width, in_channels)
        kernels: Filter/kernel tensor of shape (kernel_height, kernel_width, in_channels, out_channels)
        stride: Stride for the convolution operation (default: 1)
        padding: 'same' to maintain spatial dimensions with zero-padding, or 'valid' for no padding
        activation: Activation function to apply ('relu' or None)
        
    Returns:
        Output tensor of shape (out_height, out_width, out_channels)
    """
    in_height, in_width, in_channels = input_feature_maps.shape
    kernel_height, kernel_width, _, out_channels = kernels.shape
    
    # Calculate output dimensions and padding if needed
    if padding == 'same':
        # Calculate padding needed to maintain spatial dimensions
        pad_height = ((in_height - 1) * stride + kernel_height - in_height) // 2
        pad_width = ((in_width - 1) * stride + kernel_width - in_width) // 2
        # Pad the input
        padded_input = np.pad(input_feature_maps, 
                             ((pad_height, pad_height), 
                              (pad_width, pad_width), 
                              (0, 0)), 
                             mode='constant')
    elif padding == 'valid':
        pad_height, pad_width = 0, 0
        padded_input = input_feature_maps
    else:
        raise ValueError("Padding must be 'same' or 'valid'")
    
    # Calculate output dimensions
    out_height = (in_height + 2 * pad_height - kernel_height) // stride + 1
    out_width = (in_width + 2 * pad_width - kernel_width) // stride + 1
    
    # Initialize output tensor
    output = np.zeros((out_height, out_width, out_channels))
    
    # Perform cross-correlation 
    for i in range(out_height):
        for j in range(out_width):
            # Calculate input window position
            h_start = i * stride
            h_end = h_start + kernel_height
            w_start = j * stride
            w_end = w_start + kernel_width
            
            # Extract input window
            input_window = padded_input[h_start:h_end, w_start:w_end, :]
            
            # Compute dot product for each kernel
            for k in range(out_channels):
                output[i, j, k] = np.sum(input_window * kernels[:, :, :, k])
    
    # Apply activation if specified
    if activation == 'relu':
        output = np.maximum(0, output)
    elif activation is not None:
        raise ValueError(f"Unsupported activation: {activation}")
    
    return output

# Example input (single 5x5 image with 3 channels)
input_img = np.random.rand(4, 4, 3)

# Example kernels (two 3x3 filters)
kernels = np.random.rand(3, 3, 3, 2)

# Perform convolution with stride 1, same padding, and ReLU activation
output = conv2d(input_img, kernels, stride=1, padding='same', activation='relu')

print("Input shape:", input_img.shape)
print("Kernel shape:", kernels.shape)
print("Output shape:", output.shape)