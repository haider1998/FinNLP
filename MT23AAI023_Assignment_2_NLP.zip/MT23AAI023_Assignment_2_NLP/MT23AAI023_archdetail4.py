import numpy as np

class AlexNet:
    def __init__(self, input_shape=(227, 227, 3), num_classes=1000):
        """
        Initialize AlexNet architecture with random weights
        
        Args:
            input_shape: Shape of input images (height, width, channels)
            num_classes: Number of output classes
        """
        self.input_shape = input_shape
        self.num_classes = num_classes
        
        # Initialize all layer weights and biases
        self._initialize_parameters()
    
    def _initialize_parameters(self):
        """Initialize all weights and biases for the network"""
        # Conv1: 96 filters 11x11, stride 4
        self.conv1_weights = np.random.randn(11, 11, self.input_shape[2], 96) * 0.01
        self.conv1_biases = np.zeros(96)
        
        # Conv2: 256 filters 5x5, padding same
        self.conv2_weights = np.random.randn(5, 5, 96, 256) * 0.01
        self.conv2_biases = np.zeros(256)
        
        # Conv3: 384 filters 3x3, padding same
        self.conv3_weights = np.random.randn(3, 3, 256, 384) * 0.01
        self.conv3_biases = np.zeros(384)
        
        # Conv4: 384 filters 3x3, padding same
        self.conv4_weights = np.random.randn(3, 3, 384, 384) * 0.01
        self.conv4_biases = np.zeros(384)
        
        # Conv5: 256 filters 3x3, padding same
        self.conv5_weights = np.random.randn(3, 3, 384, 256) * 0.01
        self.conv5_biases = np.zeros(256)
        
        # Dense layers
        # Original AlexNet had two 4096-unit dense layers
        self.fc1_weights = np.random.randn(6*6*256, 4096) * 0.01
        self.fc1_biases = np.zeros(4096)
        
        self.fc2_weights = np.random.randn(4096, 4096) * 0.01
        self.fc2_biases = np.zeros(4096)
        
        self.fc3_weights = np.random.randn(4096, self.num_classes) * 0.01
        self.fc3_biases = np.zeros(self.num_classes)
    
    def forward(self, X):
        """
        Forward pass through AlexNet
        
        Args:
            X: Input tensor of shape (batch_size, height, width, channels)
            
        Returns:
            Output logits (before softmax)
        """
        # Ensure input is 4D (batch, height, width, channels)
        if X.ndim == 3:
            X = X[np.newaxis, ...]
        
        # Layer 1: Conv -> ReLU -> Pool -> LRN
        conv1 = conv2d(X, self.conv1_weights, stride=4, padding='valid', activation='relu')
        conv1 = conv1 + self.conv1_biases  # Add bias after activation for our implementation
        pool1 = pool2d(conv1, pool_size=3, stride=2, mode='max', padding='valid')
        
        # Layer 2: Conv -> ReLU -> Pool -> LRN
        conv2 = conv2d(pool1, self.conv2_weights, stride=1, padding='same', activation='relu')
        conv2 = conv2 + self.conv2_biases
        pool2 = pool2d(conv2, pool_size=3, stride=2, mode='max', padding='valid')
        
        # Layer 3: Conv -> ReLU
        conv3 = conv2d(pool2, self.conv3_weights, stride=1, padding='same', activation='relu')
        conv3 = conv3 + self.conv3_biases
        
        # Layer 4: Conv -> ReLU
        conv4 = conv2d(conv3, self.conv4_weights, stride=1, padding='same', activation='relu')
        conv4 = conv4 + self.conv4_biases
        
        # Layer 5: Conv -> ReLU -> Pool
        conv5 = conv2d(conv4, self.conv5_weights, stride=1, padding='same', activation='relu')
        conv5 = conv5 + self.conv5_biases
        pool5 = pool2d(conv5, pool_size=3, stride=2, mode='max', padding='valid')
        
        # Flatten for dense layers
        flattened = pool5.reshape(pool5.shape[0], -1)  # (batch_size, 6*6*256)
        
        # Dense layers with dropout (simulated here by just doing forward pass)
        fc1 = dense_layer(flattened, self.fc1_weights, self.fc1_biases, activation='relu')
        fc2 = dense_layer(fc1, self.fc2_weights, self.fc2_biases, activation='relu')
        logits = dense_layer(fc2, self.fc3_weights, self.fc3_biases, activation=None)
        
        return logits

