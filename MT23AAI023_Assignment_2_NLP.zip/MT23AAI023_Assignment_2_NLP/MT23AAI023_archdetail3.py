import numpy as np

def dense_layer(input_features, weights, biases, activation='relu'):
    """
    Perform forward propagation through a dense (fully connected) layer.
    
    Args:
        input_features: Input tensor of shape (batch_size, input_dim) or (input_dim,)
        weights: Weight matrix of shape (input_dim, output_dim)
        biases: Bias vector of shape (output_dim,)
        activation: Activation function to apply ('relu', 'sigmoid', 'tanh', or None)
        
    Returns:
        Output tensor of shape (batch_size, output_dim) or (output_dim,)
    """
    # Ensure input is at least 2D (for batch processing)
    if input_features.ndim == 1:
        input_features = input_features[np.newaxis, :]
    
    # Perform matrix multiplication (dot product) and add bias
    output = np.dot(input_features, weights) + biases
    
    # Apply activation function
    if activation == 'relu':
        output = np.maximum(0, output)
    elif activation == 'sigmoid':
        output = 1 / (1 + np.exp(-output))
    elif activation == 'tanh':
        output = np.tanh(output)
    elif activation is not None:
        raise ValueError(f"Unsupported activation: {activation}")
    
    # Squeeze back to 1D if input was 1D
    if output.shape[0] == 1 and input_features.shape[0] == 1:
        output = output.squeeze(0)
    
    return output

# Example 1: Single sample forward pass
input_vector = np.random.rand(4)  # 4 features
weights = np.random.rand(4, 3)    # 4 inputs, 3 outputs
biases = np.random.rand(3)        # 3 biases (one per output neuron)

# Forward pass with ReLU activation
output = dense_layer(input_vector, weights, biases, activation='relu')
print("Single sample output shape:", output.shape)
print(output)

# Example 2: Batch processing
batch_input = np.random.rand(5, 4)  # 5 samples, 4 features each
weights = np.random.rand(4, 2)      # 4 inputs, 2 outputs
biases = np.random.rand(2)          # 2 biases

# Forward pass with no activation
batch_output = dense_layer(batch_input, weights, biases, activation=None)
print("\nBatch output shape:", batch_output.shape)
print(batch_output)

# Example 3: With sigmoid activation
output_sigmoid = dense_layer(input_vector, weights, biases, activation='sigmoid')
print("\nSigmoid activation output:")
print(output_sigmoid)