import numpy as np

def pool2d(input_feature_maps, pool_size=2, stride=None, mode='max', padding='valid'):
    """
    Perform 2D pooling operation on input feature maps.
    
    Args:
        input_feature_maps: Input tensor of shape (height, width, channels)
        pool_size: Size of the pooling window (single int for square window or tuple (h, w))
        stride: Stride for the pooling operation. If None, defaults to pool_size
        mode: 'max' for max pooling or 'avg' for average pooling
        padding: 'valid' for no padding or 'same' to maintain dimensions with padding
        
    Returns:
        Output tensor after pooling
    """
    # Handle input parameters
    if isinstance(pool_size, int):
        pool_height = pool_width = pool_size
    else:
        pool_height, pool_width = pool_size
    
    stride = stride if stride is not None else pool_height
    
    in_height, in_width, channels = input_feature_maps.shape
    
    # Calculate padding if needed
    if padding == 'same':
        # Calculate padding needed to maintain spatial dimensions
        out_height = np.ceil(in_height / stride).astype(int)
        out_width = np.ceil(in_width / stride).astype(int)
        
        pad_height = max(0, (out_height - 1) * stride + pool_height - in_height)
        pad_width = max(0, (out_width - 1) * stride + pool_width - in_width)
        
        pad_top = pad_height // 2
        pad_bottom = pad_height - pad_top
        pad_left = pad_width // 2
        pad_right = pad_width - pad_left
        
        # Pad the input
        padded_input = np.pad(input_feature_maps, 
                            ((pad_top, pad_bottom), 
                             (pad_left, pad_right), 
                             (0, 0)), 
                            mode='constant')
    elif padding == 'valid':
        padded_input = input_feature_maps
    else:
        raise ValueError("Padding must be 'same' or 'valid'")
    
    # Re-get dimensions after padding
    padded_height, padded_width, _ = padded_input.shape
    
    # Calculate output dimensions
    out_height = (padded_height - pool_height) // stride + 1
    out_width = (padded_width - pool_width) // stride + 1
    
    # Initialize output tensor
    output = np.zeros((out_height, out_width, channels))
    
    # Perform pooling operation
    for i in range(out_height):
        for j in range(out_width):
            # Calculate input window position
            h_start = i * stride
            h_end = h_start + pool_height
            w_start = j * stride
            w_end = w_start + pool_width
            
            # Extract input window
            input_window = padded_input[h_start:h_end, w_start:w_end, :]
            
            # Apply pooling operation
            if mode == 'max':
                output[i, j, :] = np.max(input_window, axis=(0, 1))
            elif mode == 'avg':
                output[i, j, :] = np.mean(input_window, axis=(0, 1))
            else:
                raise ValueError("Pooling mode must be 'max' or 'avg'")
    
    return output

# Example input (feature maps from previous convolution layer)
input_features = np.random.rand(8, 8, 3)  # 8x8 with 3 channels

# Max pooling with 2x2 window and stride 2 (most common configuration)
max_pooled = pool2d(input_features, pool_size=2, stride=2, mode='max')
print("Max pooled output shape:", max_pooled.shape)

# Average pooling with 3x3 window and stride 1
avg_pooled = pool2d(input_features, pool_size=3, stride=1, mode='avg')
print("Average pooled output shape:", avg_pooled.shape)

# Max pooling with same padding to maintain dimensions
same_pooled = pool2d(input_features, pool_size=3, stride=1, mode='max', padding='same')
print("Same padding pooled output shape:", same_pooled.shape)